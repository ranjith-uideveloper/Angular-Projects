import { Component, OnInit } from '@angular/core';

class DataForm{
  userName:string;
}

class myData{
  labeltext:string;
}

class myFormData{
  userBind:string;
  passwordBind:string;
}

class datasubmit{
  title:string;
}

@Component({
  selector: 'app-template-driven',
  templateUrl: './template-driven.component.html',
  styleUrls: ['./template-driven.component.css']
})
export class TemplateDrivenComponent implements OnInit {

  dataObj: myData = new myData();
  dataLoop:myData[]=[];

  loginForm(){
    console.log(this.dataObj.labeltext);
  }


  submitForm(){
    alert("Testing Form");
  }

  addForm(){
      alert("Adding Form");
      this.dataLoop.push(this.dataObj);
  }

  eraseForm(){
    if(this.dataLoop.length>1){
      alert("Erasing Form");
      this.dataLoop.pop();
    }
  }
  
  myformObj:myFormData = new myFormData();
  totalData:myFormData[]=[];
  formSubmit(){
    alert("Test Submission");
  }

  addMyData(){
    this.totalData.push(this.myformObj);
  }

  eraseMyData(){
    if(this.totalData.length>1){
      this.totalData.pop();
    }
  }

  DataObj: DataForm = new DataForm();
  formLoop:DataForm[]=[];


  formObj:datasubmit = new datasubmit();
  items:datasubmit[]=[];
  submitData(){

  }
  addData(){
    this.items.push(this.formObj);
  }
  removeData(){
    if(this.items.length>1){
      this.items.pop();
    }
  }


  constructor() { 
    this.formLoop.push(this.DataObj);
    this.dataLoop.push(this.dataObj);
    this.totalData.push(this.myformObj);
    this.items.push(this.formObj);
  }

  ngOnInit(): void {
  }

}
