import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { RegisterComponent } from './components/register/register.component';
import { SignupComponent } from './components/signup/signup.component';

const routes: Routes = [
  {
    path:'',component:NavbarComponent
  },
  {
    path:'login',component:LoginComponent,
  },
  {
    path:'sign-up',component:SignupComponent,
  },
  {
    path:'register',component:RegisterComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
