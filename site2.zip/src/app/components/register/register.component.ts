import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registrationForm: FormGroup;
  constructor(private myFormBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.onInitRegFormCreation();
  }

  onInitRegFormCreation() {
    this.registrationForm = this.myFormBuilder.group({
      'username': ['', [Validators.required]],
      'password': ['', [Validators.required]],
      'email': ['', [Validators.required]],
      'mobileNumber': ['', [Validators.required]],
    })

  }
  onRegister() {
    console.log(this.registrationForm.value)
  }
}
