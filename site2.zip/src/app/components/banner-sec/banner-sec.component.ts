import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-sec',
  templateUrl: './banner-sec.component.html',
  styleUrls: ['./banner-sec.component.scss']
})
export class BannerSecComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
