import { Component, OnInit } from '@angular/core';
export class User{
  
  username:string;
  password:string;
  email:string;
  mobileNumber:number;

}
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
   userObj:User=new User();
   userArr:User[]=[];
  constructor() {
   this.userObj=new User();
   this.userArr.push(this.userObj);

   }

  ngOnInit(): void {
  }
  onSignup(){
    alert("Registration Success")
    console.log(this.userObj);
  }
  onAdd(){
  this.userArr.push(this.userObj);
  }
  onRemove(){
    if(this.userArr.length>1){
      this.userArr.pop();

    }
  }
}
