import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
   blogArr:any;
 selectedId:number;
 blogIdArr:any[]=[]
  constructor(private service:DataService) { }

  ngOnInit(): void {
    this.getBlog();
  }

 getBlog(){
  this.service.getBlogDetails().subscribe(
    (response)=>{
     this.blogArr=response;
      console.log(response);
    },
    (error)=>{
      console.log(error);
    }
  )
 }
 getBlogById(){
  this.service.getBlogDetailsById(this.selectedId).subscribe(
    (response)=>{
     this.blogIdArr.push(response)
      console.log(response);
    },
    (error)=>{
      console.log(error);
    }
  )
 }
 getDetails(){
   this.getBlogById();
 }
}
