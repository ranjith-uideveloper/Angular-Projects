import { Component, OnInit } from '@angular/core';

class Employee {

  id: number;
  name1: string;
  salary: number;
  age: number;

  //  static id:number;
  //  static name1:string;
  //  static salary:number;
  //  static age:number;
  //getter /setters

}
class Person {

  firstName: string;
  lastName: string;
  email: string;
  password: string;

}

class ITEmployee extends Person { //inheritance extends 

  id: number;
  salary: number;
  designation: string;

}
class GovtEmployee extends ITEmployee {

  govtId: number;
}

interface Arithmetic { //implements
  add(num1: number, num2: number);
}
enum Days {  //using ENUM Name

  SUNDAY,
  MONDAY,
  TUE,
  WED,
  THUS,
  FRI,
  SAT
}
@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})
export class MainContentComponent implements OnInit {

  customColor:string="Green";
  customFlag:boolean=false;
  customTheme:boolean=false;

  // class1:string;
  isDisplayContent: boolean = false;
  input:any;
  jobs: string[] = ["Java Developer", "UI Devloper ", "Pyton Developer ", " .Net Developer"];

  employees: any[] = [
    {
      id: 1,
      name: "Raja",
      designation: "Java Developer",
      salary: 45000,
      department: "IT"
    },
    {
      id: 2,
      name: "karan",
      designation: "UI Developer",
      salary: 35000,
      department: "IT"
    },
    {
      id: 3,
      name: "sai",
      designation: "UX Developer",
      salary: 55000,
      department: "IT"
    }
  ]


  imgURL: string = "https://c.ndtvimg.com/2021-11/dg95g57_virat-kohli-afp_625x300_08_November_21.jpg?im=FeatureCrop,algorithm=dnn,width=806,height=605";
  imgCustomHeight: any = 400;
  imgCustomWidth: any = 600;
  text: any;
  customType: any;
  firstNumber: number;
  lastNumber: number;
  myName: string;
  result: number;
  days: Days = Days.FRI;
  itEmp: ITEmployee = new ITEmployee();
  govtEmp: GovtEmployee = new GovtEmployee();
  dummyText: string = "";

  //Object Creation
  emp: Employee = new Employee();
  //emp refernce variable or object reference
  //Employee class 
  //new keyword
  emp2: Employee = new Employee();
  age: number;
  isQualified: boolean;
  firstName: string;
  fruits: string[] = [];
  lastName: any;

  //Datatypes
  //  number
  //  boolean
  //  string
  //  null
  //  undefined
  //  array
  //  object
  //  any

  //Naming Conventions

  //varibales,classes,interfaces,enum,methods

  // lowerCamelCase
  // EmployeeObject

  add(num1: number, num2: number) {

    console.log(num1 + num2);
  }

  emp5: any[] = [];


  
  constructor() {



    console.log(`My Name :${this.myName}`)
    //Accessing static variables using Class Name
    // Employee.id=1;
    // console.log(Employee.id);
    console.log("Days:" + this.days)
    this.add(10, 20);


    // this.emp.id=1;
    // this.emp.name="sai";
    // this.emp.age=25;
    // this.emp.salary=35000;
    // this.emp2.id=2;
    // this.emp2.name="raj";
    // this.emp2.age=35;
    // this.emp2.salary=55000;

    this.firstName = "Raja";
    this.lastName = "Rani";
    this.isQualified = false;
    this.age = 56;
    this.fruits = ["Banana", "Mango"];

    console.log("First Name:" + this.firstName);
    console.log(`Last Name:${this.lastName}`);
    console.log(`Is Qualified:${this.isQualified}`);
    console.log(`Age:${this.age}`);
    console.log(`Fruits:${this.fruits}`);
    console.log(this.emp);
    console.log(this.emp2);


  }
  onAdd() {

    this.result = Number(this.firstNumber) + Number(this.lastNumber);
    this.firstNumber = null;
    this.lastNumber = null;
  }
  onDisplayText() {
    this.dummyText = "Raja";
  }
  onMouseOver() {
    this.imgCustomWidth = 800;
  }

  onChangeType() {
    if (this.text > 0) {
      this.customType = "number";
    }
    else {
      this.customType = "text";

    }
  }
ngOnInit(){
 const empArr= this.employees.filter(el=>{
    el.salary>35000;
  })
  console.log(empArr)
}
  //ngIf::

  /**
   * *ngIf=" < condition >"
   */
  onHide() {
    this.isDisplayContent = false;
    this.customFlag=false;

  }
  onShow() {
    this.isDisplayContent = true;
    this.customColor="red";
    this.customFlag=true;

  }

  onLight(){
    this.customTheme=false;
  }
  onDark(){
    this.customTheme=true;
  }

}
