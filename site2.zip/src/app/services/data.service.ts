import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }


  public getBlogDetails(){
    return this.http.get("https://jsonplaceholder.typicode.com/photos");
  }

  public getBlogDetailsById(id:number){
    return this.http.get(`https://jsonplaceholder.typicode.com/photos/${id}`);
  }
}
